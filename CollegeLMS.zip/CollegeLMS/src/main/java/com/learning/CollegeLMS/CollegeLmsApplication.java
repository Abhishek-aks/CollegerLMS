package com.learning.CollegeLMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeLmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeLmsApplication.class, args);
	}

}
