package com.learning.CollegeLMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
